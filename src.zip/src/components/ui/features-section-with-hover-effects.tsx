"use client";
import { useTranslations } from 'next-intl';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { AmenityKey } from '@/types';
import { amenityDetails } from '@/lib/data'; // Assuming amenityDetails includes icons

interface FeaturesSectionProps {
  amenities: AmenityKey[];
  className?: string;
}

export function FeaturesSectionWithHoverEffects({ amenities, className }: FeaturesSectionProps) {
  const t = useTranslations(); // Using root for ApartmentDetailPage.amenities keys

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.2 }}
      className={`grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 ${className}`}
    >
      {amenities.map((amenityKey) => {
        const amenity = amenityDetails[amenityKey];
        if (!amenity) return null;
        const IconComponent = amenity.icon;
        return (
          <motion.div key={amenityKey} variants={itemVariants}>
            <Card className="h-full transition-all duration-300 ease-in-out hover:shadow-xl hover:border-primary group">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {t(amenity.labelKey)}
                </CardTitle>
                {IconComponent && <IconComponent className="h-6 w-6 text-muted-foreground group-hover:text-primary transition-colors" />}
              </CardHeader>
              <CardContent>
                {/* You can add a brief description here if needed */}
                {/* <p className="text-xs text-muted-foreground">Description (optional)</p> */}
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
