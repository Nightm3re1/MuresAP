
'use client';

import React, { Fragment } from 'react';
import { cn } from '@/lib/utils';

interface FormattedDescriptionProps {
  text: string;
}

// Titles for 3xl font size (e.g., "What's Nearby")
const titlesFor3xl = [
  "What’s Nearby", "Ce se Află în Apropiere",
];

// Titles for 2xl font size (e.g., "Apartment Highlights", "Restaurants & Cafés")
const titlesFor2xl = [
  "Apartment Highlights", "Puncte de Atracție ale Apartamentului",
  "Stunning Indoor Comfort", "Confort Interior Remarcabil",
  "Seamless Connectivity & Convenience", "Conectivitate și Confort Fără Probleme",
  "Complimentary Perks", "Avantaje Gratuite",
  "Exceptional On-Site Amenities", "Facilități Excepționale la Proprietate",
  "Attractions & Parks", "Atracții și Parcuri",
  "Restaurants & Cafés", "Restaurante și Cafenele", "Restaurants and Cafés",
  "Public Transport", "Transport Public",
  "Airport", "Aeroporturi Apropiate", "Nearby Airports", "Aeroport",
  "Medical & Convenience", "Medical și Utilități",
];

// All main titles that structure the description
const mainTitles = [
  ...titlesFor3xl,
  ...titlesFor2xl,
];

// Titles that indicate a simple list of "Label: Value" or plain items,
// or might contain sub-categories that shouldn't get bullets themselves.
const listTitlesSimple = [
  "What’s Nearby", "Ce se Află în Apropiere",
  "Restaurants & Cafés", "Restaurante și Cafenele", "Restaurants and Cafés",
  "Public Transport", "Transport Public",
  "Airport", "Aeroporturi Apropiate", "Nearby Airports", "Aeroport",
  "Attractions & Parks", "Atracții și Parcuri",
  "Medical & Convenience", "Medical și Utilități",
];

// Specific sub-category titles that should NOT get a bullet point when they appear under a 'simple' list section
const subCategoryTitlesNoBullet = [
  "Attractions & Parks", "Atracții și Parcuri",
  "Medical & Convenience", "Medical și Utilități",
  "Restaurants & Cafés", "Restaurante și Cafenele", "Restaurants and Cafés",
  "Public Transport", "Transport Public",
  "Airport", "Aeroporturi Apropiate", "Nearby Airports", "Aeroport",
];

const renderTextWithBold = (text: string): React.ReactNode => {
  const parts = text.split(/(\*\*.*?\*\*)/g).filter(part => part.length > 0);
  return (
    <>
      {parts.map((part, i) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={i} className="font-semibold text-foreground">{part.slice(2, -2)}</strong>;
        }
        return part;
      })}
    </>
  );
};

const renderPlainText = (text: string): string => {
  return text.replace(/\*\*/g, ''); // Simple stripping of **
};

export function FormattedDescription({ text }: FormattedDescriptionProps) {
  const lines = text.split('\n');
  let currentListType: 'labeled' | 'simple' | 'paragraph' | null = null;
  let inMainSection = false;

  return (
    <div className="space-y-4 text-base leading-relaxed text-muted-foreground">
      {lines.map((line, index) => {
        let trimmedLine = line.trim();
        const displayLine = trimmedLine; // Keep original for renderTextWithBold if needed

        // Handle introductory paragraph(s) before the first main title
        if (!inMainSection && !mainTitles.includes(displayLine.replace(/\*\*/g, '')) && displayLine) {
          return <p key={index} className="mb-3">{renderTextWithBold(displayLine)}</p>;
        }
        
        if (mainTitles.includes(displayLine.replace(/\*\*/g, ''))) {
          inMainSection = true; 
          if (listTitlesSimple.includes(displayLine.replace(/\*\*/g, ''))) {
            currentListType = 'simple';
          } else {
            currentListType = 'labeled'; 
          }
        }

        if (!displayLine) {
          if (index > 0 && lines[index-1].trim() !== '' && !mainTitles.includes(lines[index-1].trim().replace(/\*\*/g, ''))) {
             return <div key={index} className="h-3"></div>; 
          }
          return <Fragment key={index}></Fragment>; 
        }

        const cleanDisplayLine = displayLine.replace(/\*\*/g, '');
        let titleClass = "text-xl leading-7"; // Default for other main titles (like Stunning Indoor Comfort)
        if (titlesFor3xl.includes(cleanDisplayLine)) {
          titleClass = "text-3xl leading-9"; 
        } else if (titlesFor2xl.includes(cleanDisplayLine)) {
          titleClass = "text-2xl leading-8";
        }

        if (mainTitles.includes(cleanDisplayLine)) {
          return (
            <h4 key={index} className={cn(
              "font-semibold text-foreground pt-5 pb-2 border-b border-border/30 mb-3",
               titleClass
            )}>
              {cleanDisplayLine}
            </h4>
          );
        }
        
        if (inMainSection && displayLine) {
          const isLabelWithValue = displayLine.startsWith('**') && displayLine.includes(':**');
          const simpleLabelValueMatch = displayLine.match(/^(.*?)\s*([:–-])\s*(.+)$/);
          const isSimpleLabelWithValue = simpleLabelValueMatch && !displayLine.startsWith('**');

          if (isLabelWithValue) {
            const separatorIndex = displayLine.indexOf(':**') + 1; // Get index of the colon
            const label = displayLine.substring(2, separatorIndex - 1).trim(); // Label part without ** and colon
            let value = displayLine.substring(separatorIndex + 1).trim(); // Description part

            return (
                <div key={index} className="flex items-start pl-3 mb-1.5">
                    <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-[9px] flex-shrink-0 shadow-sm"></div>
                    <div>
                        <span className="text-foreground font-semibold">{label}:</span>
                        {' '}
                        {renderPlainText(value)} {/* Render description as plain text */}
                    </div>
                </div>
            );
          } 
          else if (isSimpleLabelWithValue) {
            const labelText = simpleLabelValueMatch[1].trim();
            const separator = simpleLabelValueMatch[2];
            let valueContent = simpleLabelValueMatch[3].trim();
            
            // Check if this labelText itself is a known sub-category that shouldn't get a bullet
            if (subCategoryTitlesNoBullet.includes(labelText.replace(/\*\*/g, ''))) {
                 return <p key={index} className="pl-1 mb-1 mt-3 text-foreground font-semibold">{renderTextWithBold(labelText)}</p>;
            }

            return (
                <div key={index} className="flex items-start pl-3 mb-1.5">
                    <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-[9px] flex-shrink-0 shadow-sm"></div>
                    <div>
                        <strong className="text-foreground font-semibold">{labelText}</strong>
                        {separator}{' '}
                        {renderPlainText(valueContent)} {/* Render description as plain text */}
                    </div>
                </div>
            );
          }
          // Handle sub-category titles (like "Attractions & Parks" under "What's Nearby")
          // This needs to be more specific if **Some Text** is a sub-category vs. a bolded bullet item
          else if (currentListType === 'simple' && subCategoryTitlesNoBullet.includes(cleanDisplayLine) && displayLine.startsWith('**') && displayLine.endsWith('**')) {
            return <p key={index} className="pl-1 mb-1 mt-3 text-foreground font-semibold">{cleanDisplayLine}</p>;
          }
           else if (currentListType === 'simple' && subCategoryTitlesNoBullet.includes(cleanDisplayLine)) { // Plain text sub-category
            return <p key={index} className="pl-1 mb-1 mt-3 text-foreground font-semibold">{cleanDisplayLine}</p>;
          }
          // Default: plain text line or a line starting and ending with ** that isn't a title/sub-category.
          else if (!mainTitles.includes(cleanDisplayLine) && !subCategoryTitlesNoBullet.includes(cleanDisplayLine)) {
                return (
                    <div key={index} className="flex items-start pl-3 mb-1.5">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3 mt-[9px] flex-shrink-0 shadow-sm"></div>
                        <span>{renderTextWithBold(displayLine)}</span> {/* Allows for **bolded text** within these items */}
                    </div>
                );
            }
        }

        return <Fragment key={index}></Fragment>;
      })}
    </div>
  );
}
