
'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from '@/navigation';
import { cn } from '@/lib/utils';
import { useTranslations } from 'next-intl';
import { Cookie } from 'lucide-react';

const COOKIE_NAME = 'cookie_consent_mures_apartments';
const COOKIE_EXPIRY_DAYS = 365;

export function CookieConsentBanner() {
  const t = useTranslations('CookieConsent');
  const [isVisible, setIsVisible] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  const getCookie = (name: string): string | null => {
    if (typeof document === 'undefined') return null;
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop()?.split(';').shift() || null;
    return null;
  };

  const setCookie = (name: string, value: string, days: number) => {
    if (typeof document === 'undefined') return;
    let expires = '';
    if (days) {
      const date = new Date();
      date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
      expires = `; expires=${date.toUTCString()}`;
    }
    document.cookie = `${name}=${value}${expires}; path=/; SameSite=Lax`;
  };

  useEffect(() => {
    setIsMounted(true);
  }, []);

  useEffect(() => {
    if (!isMounted) return;

    const consentCookie = getCookie(COOKIE_NAME);
    if (!consentCookie) {
      const handleLoad = () => {
        setTimeout(() => setIsVisible(true), 500); 
      };
      if (document.readyState === 'complete') {
        handleLoad();
      } else {
        window.addEventListener('load', handleLoad);
        return () => window.removeEventListener('load', handleLoad);
      }
    }
  }, [isMounted]);

  const handleAccept = useCallback(() => {
    setCookie(COOKIE_NAME, 'true', COOKIE_EXPIRY_DAYS);
    setIsVisible(false);
  }, []);

  if (!isMounted) {
    return null; 
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10, transition: { duration: 0.2 } }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className={cn(
            'fixed bottom-4 left-1/2 -translate-x-1/2 z-[9999]', 
            'w-[90%] md:w-auto md:max-w-[600px]', // Changed md:w-full to md:w-auto
            'bg-background/95 backdrop-blur-sm',
            'border-t border-border',
            'rounded-t-lg',
            'shadow-[0_-2px_6px_rgba(0,0,0,0.04)]',
            'p-4 md:px-6 md:py-4' 
          )}
          role="dialog"
          aria-live="polite"
          aria-label={t('ariaLabel')}
        >
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm text-foreground">
              <Cookie className="h-4 w-4 shrink-0 text-muted-foreground" />
              <span className="font-medium">{t('messageLine1')}</span>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-4 w-full sm:w-auto shrink-0 sm:ml-auto">
              <Button
                asChild
                variant="link"
                className="p-0 h-auto text-sm text-primary hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring focus-visible:outline-offset-2 rounded"
              >
                <Link href="/cookie-policy">
                  {t('learnMoreButton')}
                </Link>
              </Button>
              <Button
                onClick={handleAccept}
                size="sm"
                className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring focus-visible:outline-offset-2 px-5 py-2.5 rounded font-semibold"
              >
                {t('okButton')}
              </Button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
