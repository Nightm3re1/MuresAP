
import { apartments, apartmentGalleryImages } from '@/lib/data';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import ApartmentDetailClientContent from './apartment-detail-client-content';
import { Meteors } from '@/components/ui/meteors';

interface ApartmentDetailPageProps {
  params: {
    slug: string;
    locale: string;
  };
}

export async function generateStaticParams() {
  const params = [];
  for (const locale of ['ro', 'en']) {
    for (const apartment of apartments) {
      params.push({ locale, slug: apartment.slug });
    }
  }
  return params;
}

export async function generateMetadata({ params }: ApartmentDetailPageProps): Promise<Metadata> {
  const apartment = apartments.find((ap) => ap.slug === params.slug);
  const locale = params.locale;

  if (!apartment) {
    return {
      title: 'Apartment Not Found',
    };
  }
  
  const name = apartment.name[locale] || apartment.name.en;
  const rawDescription = apartment.description[locale] || apartment.description.en;
  const metaDescription = typeof rawDescription === 'string' ? rawDescription.substring(0, 160) : 'View details for this apartment.';


  return {
    title: name,
    description: metaDescription,
    openGraph: {
      title: name,
      description: metaDescription,
      images: apartment.images.length > 0 ? [{ url: apartment.images[0] }] : [],
    },
  };
}


export default async function ApartmentDetailPageServerWrapper({ params }: ApartmentDetailPageProps) {
  const apartment = apartments.find((ap) => ap.slug === params.slug);

  if (!apartment) {
    notFound();
  }
  
  // Gallery images are now passed directly to ApartmentDetailClientContent
  // and sourced from lib/data.ts within that component.

  return (
    <div className="relative bg-background min-h-screen flex-grow"> 
      <Meteors number={60} className="opacity-70 -z-10 absolute inset-0" />
      <ApartmentDetailClientContent
        apartment={apartment}
        slug={params.slug}
      />
    </div>
  );
}

